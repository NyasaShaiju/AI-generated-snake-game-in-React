import React, { useEffect, useState, useRef } from 'react';
import { Play, Pause, SkipForward, SkipBack, Volume2, Music as MusicIcon, Activity } from 'lucide-react';
import { Track } from '../types';
import { synth } from '../services/Synthesizer';

const PLAYLIST: Track[] = [
  { id: 'track1', title: 'Neon Pulse', artist: 'AI Core v1', bpm: 128, mood: 'Energetic' },
  { id: 'track2', title: 'Cyber Snake', artist: 'Neural Net', bpm: 145, mood: 'Energetic' },
  { id: 'track3', title: 'Glitch Hop', artist: 'Deep Dream', bpm: 95, mood: 'Dark' },
];

export const MusicPlayer: React.FC = () => {
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(50);
  const visualizerRef = useRef<HTMLDivElement>(null);

  const currentTrack = PLAYLIST[currentTrackIndex];

  useEffect(() => {
    // Load the initial track
    synth.loadTrack(currentTrack.id as any);
  }, []);

  useEffect(() => {
    // When track changes
    if (isPlaying) {
      synth.pause();
      synth.loadTrack(currentTrack.id as any);
      synth.play();
    } else {
      synth.loadTrack(currentTrack.id as any);
    }
  }, [currentTrackIndex]);

  const togglePlay = () => {
    if (isPlaying) {
      synth.pause();
    } else {
      synth.play();
    }
    setIsPlaying(!isPlaying);
  };

  const nextTrack = () => {
    setCurrentTrackIndex((prev) => (prev + 1) % PLAYLIST.length);
  };

  const prevTrack = () => {
    setCurrentTrackIndex((prev) => (prev - 1 + PLAYLIST.length) % PLAYLIST.length);
  };

  return (
    <div className="fixed bottom-0 left-0 w-full bg-slate-900/90 backdrop-blur-md border-t border-neon-blue/30 p-4 z-40 text-white shadow-[0_-5px_20px_rgba(0,243,255,0.1)]">
      <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Track Info */}
        <div className="flex items-center gap-4 w-full md:w-1/3">
          <div className="w-14 h-14 bg-gradient-to-br from-neon-blue to-neon-purple rounded-lg flex items-center justify-center shadow-[0_0_15px_#00f3ff] animate-pulse border border-white/20">
            <MusicIcon className="text-white w-8 h-8 drop-shadow-md" />
          </div>
          <div>
            <h3 className="font-bold text-neon-blue font-digital text-lg tracking-wide truncate drop-shadow-[0_0_3px_rgba(0,243,255,0.5)]">{currentTrack.title}</h3>
            <p className="text-xs text-gray-400 font-mono">{currentTrack.artist} • {currentTrack.bpm} BPM</p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-8">
          <button 
            onClick={prevTrack} 
            className="text-white hover:text-neon-blue transition-all duration-200 transform hover:scale-110 drop-shadow-[0_0_5px_rgba(255,255,255,0.3)] hover:drop-shadow-[0_0_10px_#00f3ff]"
          >
            <SkipBack className="w-8 h-8" strokeWidth={1.5} />
          </button>
          
          <button 
            onClick={togglePlay} 
            className="w-16 h-16 rounded-full bg-neon-blue text-black flex items-center justify-center hover:scale-105 hover:bg-white transition-all duration-300 shadow-[0_0_20px_#00f3ff] hover:shadow-[0_0_30px_#00f3ff] border-2 border-white/50"
          >
            {isPlaying ? <Pause className="w-8 h-8 fill-current drop-shadow-sm" /> : <Play className="w-8 h-8 fill-current ml-1 drop-shadow-sm" />}
          </button>
          
          <button 
            onClick={nextTrack} 
            className="text-white hover:text-neon-blue transition-all duration-200 transform hover:scale-110 drop-shadow-[0_0_5px_rgba(255,255,255,0.3)] hover:drop-shadow-[0_0_10px_#00f3ff]"
          >
            <SkipForward className="w-8 h-8" strokeWidth={1.5} />
          </button>
        </div>

        {/* Visualizer / Extra */}
        <div className="hidden md:flex items-center gap-4 w-1/3 justify-end">
          <div className="flex gap-1 h-8 items-end" ref={visualizerRef}>
            {[...Array(8)].map((_, i) => (
              <div 
                key={i} 
                className={`w-1 bg-neon-green transition-all duration-100 ${isPlaying ? 'animate-pulse' : ''} shadow-[0_0_5px_#00ff99]`}
                style={{ 
                  height: isPlaying ? `${Math.random() * 100}%` : '20%',
                  opacity: 0.8 
                }}
              />
            ))}
          </div>
          <div className="flex items-center gap-2 text-gray-400">
            <Volume2 className="w-4 h-4" />
            <input 
              type="range" 
              min="0" 
              max="100" 
              value={volume} 
              onChange={(e) => setVolume(Number(e.target.value))}
              className="w-20 accent-neon-pink h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer shadow-[0_0_5px_rgba(255,0,255,0.3)]"
            />
          </div>
        </div>

      </div>
    </div>
  );
};