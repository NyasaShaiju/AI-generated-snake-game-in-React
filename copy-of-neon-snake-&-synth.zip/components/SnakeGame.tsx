import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GameState, GameStatus, Coordinate, Direction } from '../types';
import { Trophy, RefreshCcw, Keyboard } from 'lucide-react';

const GRID_SIZE = 20;
const CELL_SIZE = 20; // Will be scaled dynamically
const INITIAL_SPEED = 80; // Speed increased (lower interval)

export const SnakeGame: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<GameState>({
    snake: [{ x: 10, y: 10 }],
    food: { x: 15, y: 10 },
    direction: Direction.RIGHT,
    score: 0,
    highScore: 0,
    status: 'IDLE',
  });
  const directionRef = useRef<Direction>(Direction.RIGHT); // Ref to avoid closure staleness in interval
  const gameLoopRef = useRef<number | null>(null);

  // Initialize high score from local storage
  useEffect(() => {
    const saved = localStorage.getItem('snake-high-score');
    if (saved) {
      setGameState(prev => ({ ...prev, highScore: parseInt(saved) }));
    }
  }, []);

  const generateFood = (snake: Coordinate[]): Coordinate => {
    let newFood;
    let isOnSnake;
    do {
      newFood = {
        x: Math.floor(Math.random() * GRID_SIZE),
        y: Math.floor(Math.random() * GRID_SIZE),
      };
      isOnSnake = snake.some(segment => segment.x === newFood.x && segment.y === newFood.y);
    } while (isOnSnake);
    return newFood;
  };

  const gameOver = useCallback(() => {
    setGameState(prev => {
      const newHighScore = Math.max(prev.score, prev.highScore);
      localStorage.setItem('snake-high-score', newHighScore.toString());
      return { ...prev, status: 'GAME_OVER', highScore: newHighScore };
    });
    if (gameLoopRef.current) clearInterval(gameLoopRef.current);
  }, []);

  const moveSnake = useCallback(() => {
    setGameState(prev => {
      if (prev.status !== 'PLAYING') return prev;

      const newHead = { ...prev.snake[0] };
      const currentDir = directionRef.current;

      switch (currentDir) {
        case Direction.UP: newHead.y -= 1; break;
        case Direction.DOWN: newHead.y += 1; break;
        case Direction.LEFT: newHead.x -= 1; break;
        case Direction.RIGHT: newHead.x += 1; break;
      }

      // Check walls
      if (newHead.x < 0 || newHead.x >= GRID_SIZE || newHead.y < 0 || newHead.y >= GRID_SIZE) {
        gameOver();
        return prev;
      }

      // Check self collision
      if (prev.snake.some(seg => seg.x === newHead.x && seg.y === newHead.y)) {
        gameOver();
        return prev;
      }

      const newSnake = [newHead, ...prev.snake];
      let newScore = prev.score;
      let newFood = prev.food;

      // Check food
      if (newHead.x === prev.food.x && newHead.y === prev.food.y) {
        newScore += 10;
        newFood = generateFood(newSnake);
      } else {
        newSnake.pop();
      }

      return {
        ...prev,
        snake: newSnake,
        score: newScore,
        food: newFood,
        direction: currentDir // Sync state direction for rendering if needed, though ref drives logic
      };
    });
  }, [gameOver]);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    // Prevent default scrolling for arrow keys
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) {
      e.preventDefault();
    }

    const currentDir = directionRef.current;

    switch (e.key) {
      case 'ArrowUp':
      case 'w':
      case 'W':
        if (currentDir !== Direction.DOWN) directionRef.current = Direction.UP;
        break;
      case 'ArrowDown':
      case 's':
      case 'S':
        if (currentDir !== Direction.UP) directionRef.current = Direction.DOWN;
        break;
      case 'ArrowLeft':
      case 'a':
      case 'A':
        if (currentDir !== Direction.RIGHT) directionRef.current = Direction.LEFT;
        break;
      case 'ArrowRight':
      case 'd':
      case 'D':
        if (currentDir !== Direction.LEFT) directionRef.current = Direction.RIGHT;
        break;
      case ' ':
        // Toggle pause/play logic could go here, or restart if game over
        break;
    }
  }, []);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  useEffect(() => {
    if (gameState.status === 'PLAYING') {
      const intervalId = window.setInterval(moveSnake, INITIAL_SPEED);
      gameLoopRef.current = intervalId;
      return () => clearInterval(intervalId);
    }
  }, [gameState.status, moveSnake]);

  // Drawing Logic
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw Grid (Subtle)
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    for (let i = 0; i <= GRID_SIZE; i++) {
      ctx.beginPath();
      ctx.moveTo(i * CELL_SIZE, 0);
      ctx.lineTo(i * CELL_SIZE, GRID_SIZE * CELL_SIZE);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i * CELL_SIZE);
      ctx.lineTo(GRID_SIZE * CELL_SIZE, i * CELL_SIZE);
      ctx.stroke();
    }

    // Draw Food
    ctx.fillStyle = '#ff00ff';
    ctx.shadowBlur = 15;
    ctx.shadowColor = '#ff00ff';
    const fx = gameState.food.x * CELL_SIZE;
    const fy = gameState.food.y * CELL_SIZE;
    ctx.beginPath();
    ctx.arc(fx + CELL_SIZE / 2, fy + CELL_SIZE / 2, CELL_SIZE / 2 - 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Draw Snake with trail effect
    gameState.snake.forEach((seg, index) => {
      const isHead = index === 0;
      
      // Calculate opacity/intensity based on index (head is 1, tail fades)
      // We want the tail to never be fully invisible, so we floor it at 0.3
      const opacity = Math.max(0.3, 1 - (index / (gameState.snake.length + 2)));
      
      ctx.fillStyle = isHead ? '#00f3ff' : `rgba(0, 255, 153, ${opacity})`;
      
      // Glow intensity fades with the tail
      ctx.shadowBlur = isHead ? 25 : (15 * opacity);
      ctx.shadowColor = isHead ? '#00f3ff' : '#00ff99';
      
      const x = seg.x * CELL_SIZE;
      const y = seg.y * CELL_SIZE;
      
      // Rounded rects for segments
      const radius = 4;
      ctx.beginPath();
      ctx.roundRect(x + 1, y + 1, CELL_SIZE - 2, CELL_SIZE - 2, radius);
      ctx.fill();
    });
    ctx.shadowBlur = 0;

  }, [gameState]);

  const startGame = () => {
    setGameState(prev => ({
      ...prev,
      snake: [{ x: 10, y: 10 }],
      food: { x: 15, y: 10 },
      score: 0,
      direction: Direction.RIGHT,
      status: 'PLAYING'
    }));
    directionRef.current = Direction.RIGHT;
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 relative z-10 w-full max-w-2xl mx-auto">
      
      {/* Score Header */}
      <div className="w-full flex justify-between items-center mb-6 bg-slate-800/50 p-6 rounded-xl border border-slate-700 backdrop-blur-sm shadow-neon-blue">
        <div className="flex items-center gap-4">
          <div className="bg-neon-green/20 p-3 rounded-lg shadow-[0_0_10px_rgba(0,255,153,0.3)]">
            <Trophy className="text-neon-green w-8 h-8 drop-shadow-md" />
          </div>
          <div className="flex flex-col">
            <span className="text-xs text-slate-400 font-digital tracking-widest mb-1">HIGH SCORE</span>
            <span className="text-4xl font-bold font-digital text-neon-green drop-shadow-[0_0_5px_rgba(0,255,153,0.8)] glitch-text">
              {gameState.highScore}
            </span>
          </div>
        </div>

        <div className="flex flex-col items-end">
          <span className="text-xs text-slate-400 font-digital tracking-widest mb-1">CURRENT SCORE</span>
          <span className="text-6xl font-bold font-digital text-neon-blue drop-shadow-[0_0_8px_rgba(0,243,255,0.8)] glitch-text">
            {gameState.score}
          </span>
        </div>
      </div>

      {/* Game Board Wrapper */}
      <div className="relative p-1 rounded-xl bg-gradient-to-br from-neon-blue via-purple-500 to-neon-pink shadow-[0_0_20px_rgba(188,19,254,0.3)]">
        <div className="bg-slate-950 rounded-lg p-2 relative overflow-hidden">
          <canvas
            ref={canvasRef}
            width={GRID_SIZE * CELL_SIZE}
            height={GRID_SIZE * CELL_SIZE}
            className="block rounded bg-slate-900/50"
          />
          
          {/* Overlays */}
          {gameState.status !== 'PLAYING' && (
            <div className="absolute inset-0 bg-black/70 backdrop-blur-sm flex flex-col items-center justify-center z-20">
              {gameState.status === 'GAME_OVER' && (
                <div className="text-neon-pink font-bold text-4xl mb-4 animate-pulse font-digital tracking-widest drop-shadow-[0_0_10px_#ff00ff]">GAME OVER</div>
              )}
              {gameState.status === 'IDLE' && (
                <div className="text-neon-blue font-bold text-3xl mb-4 font-digital tracking-wider drop-shadow-[0_0_10px_#00f3ff]">NEON SNAKE</div>
              )}
              
              <button 
                onClick={startGame}
                className="group relative px-8 py-3 bg-transparent overflow-hidden rounded-md border border-neon-blue text-neon-blue font-bold hover:text-black transition-all duration-300 shadow-[0_0_10px_rgba(0,243,255,0.3)]"
              >
                <div className="absolute inset-0 w-0 bg-neon-blue transition-all duration-[250ms] ease-out group-hover:w-full"></div>
                <span className="relative flex items-center gap-2 font-digital">
                  {gameState.status === 'GAME_OVER' ? <RefreshCcw size={20}/> : <Keyboard size={20}/>}
                  {gameState.status === 'GAME_OVER' ? 'RESTART SYSTEM' : 'START GAME'}
                </span>
              </button>
              
              <div className="mt-6 text-slate-500 text-xs font-mono flex gap-4">
                <span>↑ ↓ ← → TO MOVE</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};