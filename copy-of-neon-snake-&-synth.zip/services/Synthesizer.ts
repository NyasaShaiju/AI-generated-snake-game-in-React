// A simple procedural music engine using Web Audio API to simulate AI-generated tracks.

export class Synthesizer {
  private audioCtx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private currentInterval: number | null = null;
  private bpm: number = 120;
  private currentNoteIndex: number = 0;
  private melody: number[] = [];
  private bassline: number[] = [];

  // Frequency map for a pentatonic scale (approx)
  private static SCALES = {
    'cyber-minor': [261.63, 311.13, 349.23, 392.00, 466.16, 523.25], // C Minor Pentatonic
    'neon-drive': [293.66, 329.63, 369.99, 440.00, 493.88, 587.33], // D Major ish
    'dark-void': [196.00, 220.00, 233.08, 293.66, 311.13, 392.00], // G Minor exotic
  };

  constructor() {
    // Initialize on user interaction usually, handled in play
  }

  private initContext() {
    if (!this.audioCtx) {
      this.audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  }

  // Generates a random sequence based on a seed (simulating AI composition)
  private generateSequence(length: number, scale: number[]): number[] {
    const seq = [];
    for (let i = 0; i < length; i++) {
      if (Math.random() > 0.3) {
        const note = scale[Math.floor(Math.random() * scale.length)];
        seq.push(note);
      } else {
        seq.push(0); // Rest
      }
    }
    return seq;
  }

  public loadTrack(type: 'track1' | 'track2' | 'track3') {
    let scale = Synthesizer.SCALES['cyber-minor'];
    this.bpm = 120;

    if (type === 'track1') { // Neon Pulse
      scale = Synthesizer.SCALES['cyber-minor'];
      this.bpm = 128;
      this.melody = [261.63, 0, 311.13, 261.63, 392.00, 0, 349.23, 311.13, 261.63, 523.25, 466.16, 0, 392.00, 349.23, 311.13, 0];
      this.bassline = [65.41, 65.41, 0, 65.41, 77.78, 0, 87.31, 65.41];
    } else if (type === 'track2') { // Cyber Snake
      scale = Synthesizer.SCALES['neon-drive'];
      this.bpm = 145;
      this.melody = this.generateSequence(32, scale); // "AI" generated
      this.bassline = [73.42, 0, 73.42, 0, 73.42, 98.00, 73.42, 110.00];
    } else { // Glitch Hop
      scale = Synthesizer.SCALES['dark-void'];
      this.bpm = 95;
      this.melody = this.generateSequence(16, scale);
      this.bassline = [49.00, 0, 0, 49.00, 58.27, 0, 49.00, 0];
    }
    
    this.currentNoteIndex = 0;
  }

  public play() {
    this.initContext();
    if (this.audioCtx?.state === 'suspended') {
      this.audioCtx.resume();
    }
    
    if (this.isPlaying) return;
    this.isPlaying = true;

    const stepTime = (60 / this.bpm) * 1000 / 4; // 16th notes

    this.currentInterval = window.setInterval(() => {
      this.playStep();
    }, stepTime);
  }

  public pause() {
    this.isPlaying = false;
    if (this.currentInterval) {
      clearInterval(this.currentInterval);
      this.currentInterval = null;
    }
  }

  private playStep() {
    if (!this.audioCtx) return;

    const now = this.audioCtx.currentTime;

    // Melody
    const melNote = this.melody[this.currentNoteIndex % this.melody.length];
    if (melNote > 0) {
      this.playOscillator(melNote, now, 'triangle', 0.1, 0.1);
    }

    // Bass
    const bassNote = this.bassline[this.currentNoteIndex % this.bassline.length];
    if (bassNote > 0) {
      this.playOscillator(bassNote, now, 'sawtooth', 0.15, 0.2);
    }

    // Hi-hat (every other beat mostly)
    if (this.currentNoteIndex % 2 === 0) {
      this.playNoise(now);
    }

    // Kick (every 4 beats)
    if (this.currentNoteIndex % 4 === 0) {
      this.playKick(now);
    }

    this.currentNoteIndex++;
  }

  private playOscillator(freq: number, time: number, type: OscillatorType, duration: number, vol: number) {
    if (!this.audioCtx) return;
    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, time);

    gain.gain.setValueAtTime(vol, time);
    gain.gain.exponentialRampToValueAtTime(0.01, time + duration);

    osc.connect(gain);
    gain.connect(this.audioCtx.destination);

    osc.start(time);
    osc.stop(time + duration);
  }

  private playNoise(time: number) {
    if (!this.audioCtx) return;
    const bufferSize = this.audioCtx.sampleRate * 0.05; // Short duration
    const buffer = this.audioCtx.createBuffer(1, bufferSize, this.audioCtx.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.audioCtx.createBufferSource();
    noise.buffer = buffer;
    
    // Highpass filter for hi-hat sound
    const filter = this.audioCtx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.value = 5000;

    const gain = this.audioCtx.createGain();
    gain.gain.setValueAtTime(0.05, time);
    gain.gain.exponentialRampToValueAtTime(0.01, time + 0.05);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.audioCtx.destination);

    noise.start(time);
  }

  private playKick(time: number) {
    if (!this.audioCtx) return;
    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc.frequency.setValueAtTime(150, time);
    osc.frequency.exponentialRampToValueAtTime(0.01, time + 0.5);

    gain.gain.setValueAtTime(0.5, time);
    gain.gain.exponentialRampToValueAtTime(0.01, time + 0.5);

    osc.connect(gain);
    gain.connect(this.audioCtx.destination);

    osc.start(time);
    osc.stop(time + 0.5);
  }
}

export const synth = new Synthesizer();
